<?php
    $host="localhost";
    $login="root";
    $password="";
    $database="projekt_szachy";
?>